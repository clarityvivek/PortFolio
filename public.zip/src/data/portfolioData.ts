export interface Project {
  id: number;
  title: string;
  tagline: string;
  description: string;
  category: "Full-Stack" | "ML-Systems" | "Hardware-IoT";
  techStack: string[];
  githubLink: string;
  engineeringHighlight: string;
}

export const portfolioMetadata = {
  name: "Vivek Rana",
  title: "Full-Stack & ML Systems Engineer",
  institution: "National Institute of Technology, Kurukshetra",
  department: "B.Tech IIoT (Electronics & Communication Engineering)",
  email: "vivekranarajput999@gmail.com",
  github: "https://github.com/clarityvivek",
  linkedin: "https://linkedin.com/in/vivek-rana-58a336336",
  resumeUrl: "/resume.pdf", // Place your resume PDF in the public/ folder named resume.pdf
  profileImg: "/IMG_20251128_205455430_HDR~2.jpg.jpg" // Place your photo in the public/ folder named exactly this
};

export const projectsData: Project[] = [
  {
    id: 1,
    title: "Malicious URL Detection Engine",
    tagline: "High-throughput machine learning security system parsing real-time web telemetry data vectors.",
    description: "Engineered an asynchronous malware screening backend infrastructure capable of separating system log threats from structured string parameters. Automated data pipeline preprocessing matrices utilizing Pandas for high-speed algorithmic evaluations.",
    category: "ML-Systems",
    techStack: ["Python", "FastAPI", "MongoDB", "Pandas", "Scikit-Learn", "GitHub"],
    githubLink: "https://github.com/clarityvivek",
    engineeringHighlight: "Designed custom asynchronous REST endpoint handlers within FastAPI, accelerating pipeline screening throughput and routing valid payloads safely into persistent MongoDB clusters."
  },
  {
    id: 2,
    title: "eDNA Machine Learning Pipeline",
    tagline: "Data evaluation framework selected for Smart India Hackathon (SIH) 2025 Internal Matrix.",
    description: "Contributed to specialized data extraction models, optimization lifecycles, and predictive tracking workflows. Preprocessed raw biological telemetry data strings, engineered computational feature maps, and ran rigorous validation sweeps to eliminate algorithmic skew.",
    category: "ML-Systems",
    techStack: ["Python", "Machine Learning", "Data Analytics", "Feature Engineering", "Git"],
    githubLink: "https://github.com/clarityvivek",
    engineeringHighlight: "Successfully cleared the Internal Selection Round for SIH 2025 by optimizing multi-variant feature analysis models to execute efficiently without model degradation."
  },
  {
    id: 3,
    title: "Embedded RF-Controlled Navigation System",
    tagline: "Wireless hardware-firmware integration matrix running processing control loops in real-time.",
    description: "Built a remote telemetry physical vehicle using microcontrollers paired with dedicated H-bridge motor drivers. Programmed memory-conscious runtime firmware blocks to handle radio-frequency data packet streams cleanly over spatial distance matrices.",
    category: "Hardware-IoT",
    techStack: ["C++", "C", "Arduino Uno", "Embedded Logic", "Hardware Integration"],
    githubLink: "https://github.com/clarityvivek",
    engineeringHighlight: "Debugged complex firmware-to-hardware interface synchronization errors, optimizing signal response latency fields across RF communication lines."
  }
];

export const coreSkillMatrix = {
  languages: ["C++", "C", "Python", "Java", "JavaScript", "TypeScript"],
  frameworks: ["React", "FastAPI", "Express.js", "Node.js", "Tailwind CSS v4"],
  dataStorage: ["MongoDB", "SQL Basics", "Persistent JSON Systems"],
  coursework: ["Data Structures & Algorithms", "Object Oriented Programming (OOP)", "Computer Networks", "Computer Architecture", "Machine Learning & Data Analytics"]
};